/*var background =                    document.getElementById("hbackground");
   background.src = "bg-1.svg";*/

var bhbackground = document.getElementById("bhbackground");

var hground = document.getElementById("hground");

var hlogo = document.getElementById("hlogo");
    hlogo.src = "img/logo.svg";

var hplay = document.getElementById("hplay");
    hplay.src = "img/play-btn.svg";

//var hlogin = document.getElementById("hlogin");
   // hlogin.src= "login-btn.svg";

var hrank = document.getElementById("hrank");
    hrank.src= "img/ranking-btn.svg";

var hquest = document.getElementById("hquest");
    hquest.src = "img/hquest.svg";

var hset = document.getElementById("hset");
    hset.src = "img/hset.svg";

var htiger = document.getElementById("htiger");
    htiger.src = "img/tiger1.svg";

var hrhino = document.getElementById("hrhino");
    hrhino.src = "img/rhino1.svg";

var happle = document.getElementById("happle");
    happle.src = "img/apple.svg";

var hbody = document.getElementById("hbody");


