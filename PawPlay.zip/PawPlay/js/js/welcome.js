

var lwelcome = document.getElementById("lwelcome");


var lground = document.getElementById("lground");

var lx = document.getElementById("lx");
    lx.src = "hx.svg";

var llogin = document.getElementById("llogin");
    llogin.src = "login-btn.svg";

var lsignup = document.getElementById("lsignup");
    lsignup.src = "hsignup.svg";

var lguest = document.getElementById("lguest");
    lguest.src = "hguest.svg";

var lcancel = document.getElementById("lcancel");
    lcancel.src = "cancel.svg";

var lbody = document.getElementById("lbody");