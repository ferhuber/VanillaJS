var sback = document.getElementById("sback");
    sback.src = "back.svg";


var sok = document.getElementById("sok");
    sok.src = "ok.svg";

var scancel = document.getElementById("scancel");
    scancel.src = "cancel.svg";

var SUN = document.getElementById("SUN");
    SUN.src = "input.svg";

var SPW = document.getElementById("SPW");
    SPW.src = "input.svg";

var SEM = document.getElementById("SEM");
    SEM.src = "input.svg";

var sground = document.getElementById("sground");

var sbody = document.getElementById("sbody");